准备
======

基础环境检查
----------------

在部署工作开始前，应件着手检查我们接手的基础环境，一般来说，需要一下几项检查：

* 检查确认公网、租户网、存储网等网络规划；

* 检查确认集群节点网卡状态、配置是否跟网络规划一致；

* 检查 YUM 是否正确可用，软件包版本是否符合预期；

* 检查 DNS 服务器是否正确可用， 需要用到的域名是否能正常解析；

* 确认数据库是否需要使用 SSD ，检查 SSD 状态和盘符是否符合预期。

Ansible 部署机准备
---------------------

.. image:: img/prepare-1.png
    :width: 500px

我们推荐在生产环境部署 OpenStack 环境时，将 Ansible 部署机与 OpenStack 节点分离\
开，如果是测试环境，可以考虑使用某个 OpenStack 节点作为部署用机.

操作系统配置
>>>>>>>>>>>>>

1. CentOS 7 版本及以上操作系统；

2. 2.5.x 版本以上 Ansible；

  YUM 源中提供的 Ansible ，一般是 2.4.x 版本，可以事先下载好 Ansible 2.5.x 安装包，使用 yum 本地安装的方式进行安装。

.. code-block:: bash

    # yum localinstall -y Ansible-2.5.x...el7.rpm

3. 安装 Ansible 依赖包： python-netaddr；

.. code-block:: bash

    # yum install -y python-netaddr


4. 部署机到 OpenStack 各节点的 SSH 免密;

5. Clone 最新版本 Ansible 部署代码。

  仓库地址： 172.18.211.200:29418/deploy-v2

.. _集群初始化:

集群初始化
---------------

.. image:: img/prepare-2.png
    :width: 500px

OpenStack 节点主机初始化工作，由 system_init 这个角色来完成，下面将简单说明该role都完成了哪些工作。相关代码路径：

.. code-block:: bash

    ./roles/system_init

主机名
>>>>>>>>>

通常我们为方便管理，会统一为 OpenStack 节点更改主机名，命名规则为：使用字母 ‘e’ 替换主机管理网IP的 '.' 组成字符串，作为主机名使用。

DNS
>>>>>>

OpenStack 各组件间通信的 endpoint 我们使用域名的形势访问，所以，需要配置 DNS 服务器，通常 DNS 服务器在部署前已完成搭建并完成解析配置。

Kernel
>>>>>>>>>>

根据 OpenStack 集群需求，我们通常需要通过文件 sysctl.conf 和 limits.conf 来调整一些内核参数

SELinux/Firewalld
>>>>>>>>>>>>>>>>>>>>>

为避免部署以及运维过程中一些不必要的问题，我们通常选择关闭 SELinux 和 Firewalld

Logrotate
>>>>>>>>>>>

我们为日志轮转，设置了一些规则：

1. 每周轮转 1 次
2. 备份日志保存 4 周

这些规则，视情况而定，如果有必要，可以进行修改.

YUM
>>>>>>>

由于 OpenStack 是经我司二次研发定制的，所以需要配置我们自己的 YUM 源，而不能直接使用社区的 YUM 配置。

SSH
>>>>>>>

修改sshd配置文件权限，以提升服务器访问安全性。

必要工具安装
>>>>>>>>>>>>>>

安装必要常用工具，以方便后续的操作和运维，一般安装工具如下：

1. vim
2. net-tools
3. ntpdate

.. attention:: 上述内容，在执行操作之前，需要先完成 :ref:`配置部署`

.. _配置部署:

部署配置
-----------

.. image:: img/prepare-3.png
    :width: 500px



Ansible引用一些包含强制和可选配置指令的文件。在运行Ansible playbooks之\
前，修改这些文件来定义目标环境。相关代码路径：

.. code-block:: bash

    ./config.yml
    ./hosts

配置任务包括:

1. OpenStack 部署所依赖的基础服务、中间件等配置；

2. 按角色分类 (E.g controller, network) 的集群主机列表；

3. OpenStack 集群网卡、高可用地址、管理网、租户网、存储网等配置；

4. 部署集群所用软件版本；

5. OpenStack 计算、网络、存储所用后端

.. attention:: 在文件 ``config.yml`` 中所有配置项，已经在该文件中有详细解释说明，在做配置使用时，请仔细阅读这些注释，忽略这些信息可能会产生一些不必要的错误。

下面，我们将对 ``hosts``、 ``config.yml`` 两个文件的主体内容，做一个简单的介绍：


**hosts**

.. code-block:: bash

    # hosts
    [ceph_rados_gateway]            # Ceph RGW 网关(对象存储)
    [ceph_rados_gateway_ha]         # Ceph RGW 网关高可用 VIP
    [dns_server]                    # DNS server 节点
    [os_ha]                         # OpenStack 控制节点组件高可用vip
    [proxy_ha]                      # novncproxy (分离部署时)高可用vip
    [memcached_server]              # Memcached 节点
    [mariadb]                       # MariaDB 节点
    [mysql]                         # MySQL 节点
    [nova_rabbit]                   # Nova 组件用 RabbitMQ 集群节点
    [other_rabbit]                  # 其他组件用 RabbitMQ 集群节点
    [kgc_server]                    # Keystone、Glance、Cinder 控制节点
    [nova_server]                   # Nova 控制节点
    [proxy]                         # novncproxy 节点
    [neutron_server]                # Neutron 控制节点
    [compute]                       # 计算节点
    [network]                       # 网络节点
    [ironic]                        # Bare Metal 节点
    [ironic_inspector]              # ronic inspector 节点
    [vmware_compute]                # 对接 VMware 的 compute 节点

.. note:: 需要说明的是，Mariadb 部分，为数据库使用 Galera 集群时配置， 如果选用主从同步或单节点数据库， 则填写 MySQL 部分。


**config.yml**

.. code-block:: bash

    # 各组件 endpoint 的域名配置
    domain:

    # NTP 服务器配置
    ntp_server:

    # YUM 服务器配置
    yum_server:

    # 数据库网络相关配置
    # MariaDB
    network_mariadb:
       internal:
         interface:
         cidr:

    # MySQL:
    network_mysql:
      internal:
        interface:
        cidr:
        vip:

    # OpenStack 集群网络相关配置
    network_openstack:
      # 管理网
      management:
        cidr:
        vip:
        proxy_vip:
      # 租户网
      tenant:
        interface:
          compute:
          network:
          vmware_compute:
        cidr:
        network_type:
        vlan_range:
      # 公网(或者是模拟公网)
      public:
        interface:
          compute:
          network:
          vmware_compute:
        cidr:
        vlan_id:
      # 存储网
      storage:
        cidr:
      # Ironic provision 网(非 Ironic 环境无需配置)
      provision:
        cidr:
        vlan_id:
        dhcp_range_start:
        dhcp_range_end:
        vip:
        switch_info:
      # Ironic Inspector 网(非 Ironic 环境无需配置)
      inspector:
        cidr:
        dhcp_range_start:
        dhcp_range_end:

    # OpenStack 版本配置，可进行全局配置，或单独配置某个组件或客户端版本
    version_openstack:
      global:
      cinder:
      cinderclient:
      glance:
      glanceclient:
      ironic:
      ironicclient:
      ironic_inspector:
      keystone:
      keystoneclient:
      neutron:
      neutronclient:
      nova:
      novaclient:
      openstackclient:

    # OpenStack 后端配置
    backend_openstack:
      # 存储后端配置
      cinder：
        backends:
      glance:
        stores:
      # 网络后端配置
      neutron：
        l3_mode:
      # 计算后端配置
      nova:
        compute_driver:
        images_type:

    # 使用 VMware ESXI 作为 OpenStack 后端时的配置
    vmware_openstack:
      username:
      password:
      host:
      cluster_name:
      network_maps:
      uplink_maps:

.. attention:: 各项配置值均为字符串形式，填写时，请注意双引号 ``" "`` 的使用。
