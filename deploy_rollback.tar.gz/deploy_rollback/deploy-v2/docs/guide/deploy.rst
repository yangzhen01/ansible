部署
======

运行 playbooks
-----------------

.. image:: img/deploy-1.png
    :width: 500px

整个安装过程，分为三个步骤，需要运行三个主要 playbook：

* ``setup_hosts.yml`` 该 playbook 将完成 OpenStack 集群各主机的初始化任务，所完成操作内容见 :ref:`集群初始化`。

* ``setup_middleware.yml`` 该 playbook 将完成 OpenStack 集群所依赖的中间件的部署安装，如 MySQL(MariaDB)、 HAproxy、 Memcached、 RabbitMQ等

* ``setup_openstack.yml`` 该 playbook 将完成 OpenStack 集群的部署工作包含核心组件 Keystone、Nova、Neutron、Glance、Cinder 等

初始化集群
>>>>>>>>>>>>

进入 ``./playbooks`` 目录，执行以下命令：

.. code-block:: bash

    # ansible-playbook setup_hosts.yml


部署中间件
>>>>>>>>>>>>>

在部署数据库的时候，需要根据选用类型不同(E.g. Galera、主从等)，需要更改 ``setup_middleware.yml`` 中\
要执行的 playbook 。

E.g. 数据库使用 Galera 集群方式：

.. code-block:: bash

    # cat setup_middleware.yml
    - import_playbook: ntp.yml
    - import_playbook: memcached_install.yml
    - import_playbook: rabbitmq.yml
    - import_playbook: haproxy_keepalived_install.yml
    - import_playbook: mariadb_install.yml
    #- import_playbook: mysql_install.yml

在 ``./playbooks/`` 目录下，执行以下命令：

.. code-block:: bash

    # ansible-playbook setup_middleware.yml


.. warning:: 请注意，部署中间件这个步骤在完成 OpenStack 部署之后(维护阶段)，切记不要再重复执行，否则会导致 OpenStack 集群出错。

OpenStack 集群部署
>>>>>>>>>>>>>>>>>>>>>>

同样，根据集群的部署规划，需要调整 playbook 来完成个性化部署定制，例如是否部署 Ironic、是否启用 L3 模式等，下面是 ``setup_openstack.yml`` 文件\
的说明：

.. code-block:: bash

    # cat setup_openstack.yml
    - import_playbook: keystone.yml                             # 部署 Keystone 服务
    - import_playbook: glance_install.yml                       # 部署 Glance 服务
    - import_playbook: cinder_controller_install.yml            # 部署 controller 节点 Cinder 服务
    - import_playbook: neutron_controller_install.yml           # 部署 controller 节点 Neutron 相关服务
    - import_playbook: nova_controller.yml                      # 部署 controller 节点 Nova 相关服务
    - import_playbook: nova_novncproxy.yml                      # 部署 Nova 的 novncproxy 服务
    - import_playbook: cinder_compute_install.yml               # 部署 compute 节点 Cinder 服务
    - import_playbook: neutron_compute.yml                      # 部署 compute 节点 Neutron 相关服务
    - import_playbook: nova_compute.yml                         # 部署 compute 节点 Nova 相关服务
    - import_playbook: neutron_network.yml                      # 部署网络节点，启用 L3 模式
    #- import_playbook: ceph_rados_gateway.yml                   # 部署 Ceph RGW，部署 Ironic 需要用到对象存储
    #- import_playbook: ironic_inspector.yml                     # 部署 Ironic Inspector 服务
    #- import_playbook: ironic.yml                               # 部署 Ironic 服务

在 ``./playbook/`` 目录下，执行以下命令：

.. code-block:: bash

    # ansible-playbook setup_openstack.yml

由此，完成 OpenStack 集群部署工作，准备检查验收。
