#!/usr/bin/env bash

port_name=$1
port_ip=$2
prefix=$3
mgt_port_mac=`neutron port-show ${port_name} | grep -w mac_address | awk '{print $4}'`
mgt_port_id=`neutron port-show ${port_name} | grep -w id | awk '{print $4}'`

ovs-vsctl  --may-exist add-port br-int o-hm0 -- set Interface o-hm0 type=internal -- set Interface o-hm0 external-ids:iface-status=active -- set Interface o-hm0 external-ids:attached-mac=${mgt_port_mac} -- set Interface o-hm0 external-ids:iface-id=${mgt_port_id}
ip link set dev o-hm0 address ${mgt_port_mac}
ip link set dev o-hm0 up
ip addr add ${port_ip}/${prefix} dev o-hm0

