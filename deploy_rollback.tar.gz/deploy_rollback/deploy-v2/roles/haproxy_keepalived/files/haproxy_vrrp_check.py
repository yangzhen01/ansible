import socket
import sys

SOCKET_TIMEOUT = 5

def get_status(sock_address):
    """Query haproxy stat socket
    Only VRRP fail over if the stats socket is not responding.
    :param sock_address: unix socket file
    :return: 0 if haproxy responded
    """

    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(SOCKET_TIMEOUT)
    s.connect(sock_address)
    s.send(b'show stat -1 -1 -1\n')
    data = b''


    while True:
        x = s.recv(1024)
        if not x:
            break
        data += x
    s.close()


    # if get nothing, means has no response
    if len(data) == 0:
        return 1
    return 0

def health_check(sock_addresses):
    """Invoke queries for all defined listeners
    :param sock_addresses:
    :return:
    """
    status = 0
    for address in sock_addresses:
        status += get_status(address)
    return status

def main():
    # usage python haproxy_vrrp_check.py <list_of_stat_sockets>
    # Note: for performance, this script loads minimal number of module.
    # Loading octavia modules or any other complex construct MUST be avoided.
    listeners_sockets = sys.argv[1:]
    try:
        status = health_check(listeners_sockets)
    except Exception:
        sys.exit(1)
    sys.exit(status)

if __name__ == '__main__':
    import re
    sys.argv[0] = re.sub(r'(-script\.pyw?|\.exe)?$', '', sys.argv[0])
    sys.exit(main())
