验收
======

检查验收
------------

.. image:: img/verify-1.png
    :width: 500px

在部署工作完成之后，我们需要执行以下操作来验证集群是否正常可用：

* 检查OpenStack服务状态

.. code-block:: bash

    openstack compute service list
    openstack volume service list
    openstack network agent list

* 创建公网

.. code-block:: bash

    openstack network create --external --provider-network-type  vlan --provider-physical-network external --provider-segment 213 ext-net
    openstack network create --external --provider-network-type  flat  --provider-physical-network  external  flat-net

    openstack subnet create --gateway 172.18.213.254 --allocation-pool start=172.18.213.150,end=172.18.213.190 --network ext-net --subnet-range 172.18.213.0/24 ext-subnet
    openstack --debug subnet create --network flat-net --allocation-pool start=172.28.17.11,end=172.28.17.100 --dns-nameserver 8.8.4.4 --gateway  172.28.17.250   --subnet-range  172.28.16.0/23 flat-subnet

* 创建Ironic租户网络(可选)

.. code-block:: bash

    openstack network create IronicNet --provider-network-type vlan --provider-segment 2351 --provider-physical-network external
    openstack subnet create tenant-subnet --network 14e9ed46-3e7c-4896-a50d-e900f18fe4ca  --subnet-range 192.168.1.0/24 --allocation-pool start=192.168.1.10,end=192.168.1.210


* 上传镜像

.. code-block:: bash

    glance image-create \
    --name "CentOS7.4" \
    --file /var/tmp/centos74_image \
    --disk-format raw \
    --container-format bare  \
    --visibility public \
    --property hw_qemu_guest_agent=yes  \
    --property os_type="linux" \
    --property hw_vif_multiqueue_enabled=true \
    --property hw_vif_model=e1000 \
    --progress



    openstack image create <image_name> --file <image_file> \
    --disk-forma raw --container-format bare \
    --property img_hv_type=qemu \
    --property hw_qemu_guest_agent=yes \
    --property os_type="linux"  \
    --property hw_vif_multiqueue_enabled='true' \
    --progress



* 创建租户网络

.. code-block:: bash

    openstack router create test
    openstack router set --external-gateway ext-net test     ### openstack router set --external-gateway ext-net ping router_snat

    openstack network create test
    openstack subnet create --subnet-range 10.10.10.0/24 --network test --dns-nameserver 114.114.114.114 test
    openstack router add subnet test test

* 创建flavor

.. code-block:: bash

    openstack flavor create --vcpus 1 --ram 1024 flavor1

* 创建虚拟机

.. code-block:: bash

    nova boot \
    --flavor flavor1 \
    --security-group default \
    --availability-zone nova:10e129e168e32 \
    --nic net-name=test \
    --block-device id=d7ef515a-8641-49f4-a48f-2ff6000c8003,source=image,dest=volume,bootindex=0,size=50,shutdown=remove \
    --min-count 2 \
    --meta admin_pass=123 \ test
