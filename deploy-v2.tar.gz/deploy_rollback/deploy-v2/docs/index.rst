======================
OpenStack 部署指导手册
======================

本手册用于指导用户使用 Ansible_ 部署 OpenStack_ 集群。

读者可通过 `当前进展`_ 获取当前支持情况，查阅 `目录结构`_ 了解详细部署信息。

.. _ops_deploy_supported:

--------
当前进展
--------

下面列举部署代码当前依赖的 `版本信息`_ 及 `部署支持情况`_ 。

.. _ops_deploy_supported_version:

^^^^^^^^
版本信息
^^^^^^^^

部署代码代码基于 Ansible 2.5.2 开发，实际部署时请选择 Ansible 2.5.x 版本。

部署代码与电信云 CT-Queens_ 版本深度整合， 不适用于其他 OpenStack 版本的部署。
部署代码支持的 CT-Queens_ 版本为 ``6.0.4.000`` 。

.. _ops_deploy_supported_element:

^^^^^^^^^^^^
部署支持情况
^^^^^^^^^^^^

租户网络模式

  =======================  ========
  网络模式                 是否支持
  =======================  ========
  VLAN                     yes
  VXLAN                    yes
  =======================  ========

OpenStack 组件

  =======================  ========
  组件                     是否支持
  =======================  ========
  Cinder                   yes
  Glance                   yes
  Ironic                   yes
  Ironic-inspector         yes
  Keystone                 yes
  Neutron                  yes
  Nova                     yes
  =======================  ========

中间件

  =======================  ========
  名称                     是否支持
  =======================  ========
  BIND (master + backup)   yes
  HAProxy                  yes
  Keepalived               yes
  MariaDB (Galera)         yes
  Memcached                yes
  MySQL (master + backup)  yes
  NTP                      yes
  =======================  ========

其他

  =======================  ========
  名称                     是否支持
  =======================  ========
  Ceph Rados Gateway       yes
  =======================  ========

.. _ops_deploy_content:

--------
目录结构
--------

读者可按照以下目录了解详细部署信息：

.. toctree::
   :maxdepth: 2

   guide/prepare
   guide/deploy
   guide/verify

.. seealso::

   `OpenStack 运维文档库 <http://172.28.8.216>`_
       阅读 OpenStack 运维组其他手册
   `OpenStack Documentation <https://docs.openstack.org/>`_
       获取 OpenStack 更多内容
   `Ansible Documentation <https://docs.ansible.com>`_
       了解 Ansible

.. _Ansible: https://www.ansible.com/
.. _OpenStack: https://www.openstack.org/
.. _CT-Queens: http://172.18.211.163:8090/display/Help/Q-Release
