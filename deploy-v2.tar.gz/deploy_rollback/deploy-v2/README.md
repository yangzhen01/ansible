# README

This is a tool for automated management with Ansible.

## 版本和依赖说明

支持的 Ansible 版本：`2.5.x`

支持的发行版：`CentOS 7`

需要在执行 Ansible 的节点安装以下依赖包：

* python-netaddr

## 文档说明

详细说明文档请见 `docs/`

## TODO

* 需要对用户输入的内容进行检查
* 完成同一功能的 tasks 整合到 `playbooks/common-tasks` 中
* 角色代码存在功能重复，需要改为调用其他角色完成
