#!/bin/bash

/usr/bin/python /etc/keepalived/haproxy_vrrp_check.py /var/lib/haproxy/stats; exit $?
